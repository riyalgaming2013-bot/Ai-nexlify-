
import React from 'react';

export const LoadingSpinner: React.FC = () => (
  <div className="absolute inset-0 bg-brand-bg bg-opacity-80 flex flex-col justify-center items-center z-50 animate-fade-in">
    <div className="w-16 h-16 border-4 border-brand-border border-t-neon-pink rounded-full animate-spin"></div>
    <p className="mt-4 text-neon-pink-light font-orbitron tracking-widest text-lg animate-pulse-slow">PROCESSING...</p>
  </div>
);
