
import React from 'react';

export const GenerateIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path d="M12 2.25c-5.376 0-9.75 4.374-9.75 9.75s4.374 9.75 9.75 9.75 9.75-4.374 9.75-9.75S17.376 2.25 12 2.25zM12.5 18a.5.5 0 01-1 0v-4.943l-2.22 2.22a.5.5 0 01-.707-.707L11.5 11.646V8.5a.5.5 0 011 0v3.146l2.927 2.927a.5.5 0 01-.707.707L12.5 13.057V18z" clipRule="evenodd" fillRule="evenodd" />
  </svg>
);
