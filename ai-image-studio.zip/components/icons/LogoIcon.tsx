
import React from 'react';

export const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 100 100"
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
  >
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: '#FF4081', stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: '#F50057', stopOpacity: 1 }} />
      </linearGradient>
    </defs>
    <path
      d="M50,10 A40,40 0 1,1 50,90 A40,40 0 1,1 50,10 M50,20 A30,30 0 1,1 50,80 A30,30 0 1,1 50,20"
      stroke="url(#logoGradient)"
      strokeWidth="4"
    />
    <path
      d="M35 50 L50 35 L65 50 L50 65 Z"
      fill="url(#logoGradient)"
    />
    <circle cx="50" cy="50" r="5" fill="white" />
  </svg>
);
