import React from 'react';

interface HeaderProps {
  showBackButton: boolean;
  onBack: () => void;
}

const LOGO_URL = 'https://i.ibb.co/5WDVx7GK/file-0000000038ac622fb334d423313efc3d.png';

export const Header: React.FC<HeaderProps> = ({ showBackButton, onBack }) => {
  return (
    <header className="w-full p-4 bg-brand-bg/50 backdrop-blur-sm border-b border-brand-border sticky top-0 z-40 animate-fade-in">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
            <img 
                src={LOGO_URL} 
                alt="AI Image Studio Logo" 
                className="h-8 w-8 rounded-full transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-neon-pink/50" 
            />
            <h1 className="text-2xl font-orbitron font-bold text-brand-text tracking-wider">
              AI <span className="text-neon-pink">Image Studio</span>
            </h1>
        </div>
        {showBackButton && (
             <button
                onClick={onBack}
                className="px-4 py-2 text-sm font-semibold text-brand-text bg-brand-surface rounded-md hover:bg-brand-border transition-colors flex items-center gap-2"
              >
               <svg xmlns="http://www.w.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                Home
              </button>
        )}
      </div>
    </header>
  );
};