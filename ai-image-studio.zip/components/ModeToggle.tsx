
import React from 'react';
import { AppMode } from '../types';
import { EditIcon } from './icons/EditIcon';
import { GenerateIcon } from './icons/GenerateIcon';

interface ModeToggleProps {
  mode: AppMode;
  setMode: (mode: AppMode) => void;
}

export const ModeToggle: React.FC<ModeToggleProps> = ({ mode, setMode }) => {
  const getButtonClasses = (buttonMode: AppMode) =>
    `flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md text-sm font-bold transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-neon-pink-light ${
      mode === buttonMode
        ? 'bg-neon-pink text-white shadow-lg shadow-neon-pink/30'
        : 'bg-brand-surface text-brand-text-secondary hover:bg-brand-border hover:text-brand-text'
    }`;

  return (
    <div className="flex w-full max-w-md gap-2 p-1.5 bg-brand-bg rounded-lg">
      <button
        onClick={() => setMode(AppMode.Edit)}
        className={getButtonClasses(AppMode.Edit)}
      >
        <EditIcon className="h-5 w-5" />
        <span>Image Edit</span>
      </button>
      <button
        onClick={() => setMode(AppMode.Generate)}
        className={getButtonClasses(AppMode.Generate)}
      >
        <GenerateIcon className="h-5 w-5" />
        <span>Image Generate</span>
      </button>
    </div>
  );
};
