import React from 'react';
import { AppMode } from '../types';
import { EditIcon } from './icons/EditIcon';
import { GenerateIcon } from './icons/GenerateIcon';

interface LandingPageProps {
  onSelectMode: (mode: AppMode) => void;
}

const LOGO_URL = 'https://i.ibb.co/5WDVx7GK/file-0000000038ac622fb334d423313efc3d.png';

const ModeCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
  animationClass: string;
  onClick: () => void;
}> = ({ icon, title, description, animationClass, onClick }) => (
  <div 
    className={`bg-light-surface border border-light-border rounded-xl p-8 flex flex-col items-center text-center transition-all duration-300 cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-neon-pink/20 hover:border-neon-pink/50 transform hover:-translate-y-2 ${animationClass}`}
    onClick={onClick}
  >
    <div className="bg-light-bg p-4 rounded-full mb-4 border-2 border-neon-pink">
      {icon}
    </div>
    <h3 className="font-orbitron text-2xl font-bold text-light-text mb-2">{title}</h3>
    <p className="text-light-text-secondary mb-6 flex-grow">{description}</p>
    <button className="w-full py-3 px-4 bg-neon-pink text-white font-bold rounded-md hover:bg-neon-pink-light transition-all duration-300 shadow-lg shadow-neon-pink/30 transform hover:scale-105">
      Launch Studio
    </button>
  </div>
);

export const LandingPage: React.FC<LandingPageProps> = ({ onSelectMode }) => {
  return (
    <div className="min-h-screen bg-light-bg text-light-text flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 animate-fade-in relative">
      <header className="absolute top-0 left-0 p-6 flex items-center gap-3">
        <img src={LOGO_URL} alt="Logo" className="h-10 w-10 rounded-full" />
        <span className="text-light-text-secondary font-semibold tracking-wide">Made by Yash</span>
      </header>

      <div className="text-center mb-12">
        <img 
            src={LOGO_URL} 
            alt="AI Image Studio Logo" 
            className="w-32 h-32 mx-auto mb-4 rounded-full shadow-2xl shadow-neon-pink/30 animate-spin-slow ring-2 ring-neon-pink/50 ring-offset-4 ring-offset-light-bg" 
        />
        <h1 className="text-5xl font-orbitron font-bold text-light-text tracking-wider">
          AI <span className="text-neon-pink">Image Studio</span>
        </h1>
        <p className="text-light-text-secondary mt-4 max-w-2xl mx-auto">
          Your one-stop solution for AI-powered image creation and manipulation. Choose your canvas and let your creativity flow.
        </p>
      </div>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8">
        <ModeCard
          icon={<EditIcon className="h-8 w-8 text-neon-pink-light" />}
          title="Image Edit"
          description="Upload your own image, select an area with our smart brush, and describe your desired changes. Perfect for touch-ups, modifications, and creative alterations."
          animationClass="animate-float"
          onClick={() => onSelectMode(AppMode.Edit)}
        />
        <ModeCard
          icon={<GenerateIcon className="h-8 w-8 text-neon-pink-light" />}
          title="Image Generate"
          description="Turn your words into stunning visuals. Simply type a descriptive prompt and watch our AI bring your ideas to life from scratch. The possibilities are endless."
          animationClass="animate-float-delay"
          onClick={() => onSelectMode(AppMode.Generate)}
        />
      </div>
    </div>
  );
};