
import React from 'react';

interface ControlsProps {
  brushSize: number;
  setBrushSize: (size: number) => void;
  onClearMask: () => void;
  onNewImage: () => void;
}

export const Controls: React.FC<ControlsProps> = ({ brushSize, setBrushSize, onClearMask, onNewImage }) => {
  return (
    <div className="w-full bg-brand-surface p-4 rounded-lg shadow-lg border border-brand-border space-y-4">
      <div>
        <label htmlFor="brushSize" className="block text-sm font-medium text-brand-text-secondary mb-2">
          Brush Size: <span className="font-bold text-neon-pink-light">{brushSize}</span>
        </label>
        <input
          type="range"
          id="brushSize"
          min="1"
          max="100"
          value={brushSize}
          onChange={(e) => setBrushSize(Number(e.target.value))}
          className="w-full h-2 bg-brand-border rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:bg-neon-pink [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:transition-all [&::-webkit-slider-thumb]:hover:scale-110"
        />
      </div>
      <div className="flex flex-col sm:flex-row gap-2">
        <button
          onClick={onClearMask}
          className="w-full px-4 py-2 text-sm font-semibold text-brand-text bg-brand-border rounded-md hover:bg-gray-600 transition-colors"
        >
          Clear Mask
        </button>
        <button
          onClick={onNewImage}
          className="w-full px-4 py-2 text-sm font-semibold text-brand-text bg-brand-border rounded-md hover:bg-gray-600 transition-colors"
        >
          New Image
        </button>
      </div>
    </div>
  );
};
