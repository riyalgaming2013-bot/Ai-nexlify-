
import React, { useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react';

interface ImageEditorProps {
  imageFile: File;
  brushSize: number;
}

export interface ImageEditorRef {
  getMaskAsBase64: () => string;
  resetMask: () => void;
}

export const ImageEditor = forwardRef<ImageEditorRef, ImageEditorProps>(({ imageFile, brushSize }, ref) => {
  const imageCanvasRef = useRef<HTMLCanvasElement>(null);
  const drawingCanvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const lastPosition = useRef<{ x: number; y: number } | null>(null);

  const drawImage = () => {
    const canvas = imageCanvasRef.current;
    const drawingCanvas = drawingCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    const img = new Image();
    img.src = URL.createObjectURL(imageFile);
    img.onload = () => {
      if (canvas && drawingCanvas && ctx) {
        // Maintain aspect ratio
        const container = canvas.parentElement as HTMLElement;
        const hRatio = container.clientWidth / img.width;
        const vRatio = container.clientHeight / img.height;
        const ratio = Math.min(hRatio, vRatio, 1);
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        drawingCanvas.width = canvas.width;
        drawingCanvas.height = canvas.height;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      }
    };
  };

  useEffect(() => {
    drawImage();
    window.addEventListener('resize', drawImage);
    return () => {
      window.removeEventListener('resize', drawImage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [imageFile]);

  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };
  
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    lastPosition.current = getCoordinates(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    lastPosition.current = null;
  };
  
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = drawingCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    const currentPosition = getCoordinates(e);
    if (!ctx || !currentPosition || !lastPosition.current) return;
    
    ctx.strokeStyle = 'rgba(245, 0, 87, 0.7)';
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    ctx.beginPath();
    ctx.moveTo(lastPosition.current.x, lastPosition.current.y);
    ctx.lineTo(currentPosition.x, currentPosition.y);
    ctx.stroke();
    
    lastPosition.current = currentPosition;
  };

  useImperativeHandle(ref, () => ({
    getMaskAsBase64: () => {
      const drawingCanvas = drawingCanvasRef.current;
      if (!drawingCanvas) return '';

      // Create a temporary canvas to generate the black and white mask
      const maskCanvas = document.createElement('canvas');
      maskCanvas.width = drawingCanvas.width;
      maskCanvas.height = drawingCanvas.height;
      const maskCtx = maskCanvas.getContext('2d');

      if (!maskCtx) return '';

      // Fill background with black (area to keep)
      maskCtx.fillStyle = 'black';
      maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);

      // Draw the mask content from the drawing canvas in white (area to edit)
      maskCtx.globalCompositeOperation = 'source-over';
      maskCtx.drawImage(drawingCanvas, 0, 0);

      // Change the color of the drawn parts to white
      maskCtx.globalCompositeOperation = 'source-in';
      maskCtx.fillStyle = 'white';
      maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
      
      return maskCanvas.toDataURL('image/png').split(',')[1];
    },
    resetMask: () => {
        const canvas = drawingCanvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (canvas && ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    }
  }));

  return (
    <div className="relative w-full h-full flex justify-center items-center">
      <canvas ref={imageCanvasRef} className="absolute top-0 left-0 right-0 bottom-0 m-auto rounded-lg shadow-2xl shadow-black/50" />
      <canvas
        ref={drawingCanvasRef}
        className="absolute top-0 left-0 right-0 bottom-0 m-auto cursor-crosshair"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
      />
    </div>
  );
});
