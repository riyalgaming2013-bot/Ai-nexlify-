import React, { useState, useRef } from 'react';
import { AppMode } from '../types';
import { generateImageFromPrompt, editImageWithMask } from '../services/geminiService';
import { Header } from './Header';
import { ModeToggle } from './ModeToggle';
import { ImageUploader } from './ImageUploader';
import { ImageEditor, ImageEditorRef } from './ImageEditor';
import { Controls } from './Controls';
import { LoadingSpinner } from './LoadingSpinner';

interface StudioProps {
    initialMode: AppMode;
    onExit: () => void;
}

const LOGO_URL = 'https://i.ibb.co/5WDVx7GK/file-0000000038ac622fb334d423313efc3d.png';

export const Studio: React.FC<StudioProps> = ({ initialMode, onExit }) => {
  const [mode, setMode] = useState<AppMode>(initialMode);
  const [prompt, setPrompt] = useState<string>('');
  const [originalImageFile, setOriginalImageFile] = useState<File | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [brushSize, setBrushSize] = useState<number>(30);
  const editorRef = useRef<ImageEditorRef>(null);

  const handleImageUpload = (file: File) => {
    setOriginalImageFile(file);
    setGeneratedImage(null);
    setError(null);
  };

  const handleGenerate = async () => {
    if (!prompt) {
      setError('Please enter a prompt.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);
    try {
      const imageBase64 = await generateImageFromPrompt(prompt);
      setGeneratedImage(`data:image/png;base64,${imageBase64}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = async () => {
    if (!prompt) {
      setError('Please enter a prompt to describe the edit.');
      return;
    }
    if (!originalImageFile || !editorRef.current) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const maskBase64 = editorRef.current.getMaskAsBase64();
      const hasMask = maskBase64.split('').some(char => char !== 'A'); // A is base64 for 0x00
      if (!hasMask) {
          setError('Please select an area to edit by drawing on the image.');
          setIsLoading(false);
          return;
      }
      const imageBase64 = await editImageWithMask(prompt, originalImageFile, maskBase64);
      setGeneratedImage(`data:image/png;base64,${imageBase64}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === AppMode.Generate) {
      handleGenerate();
    } else {
      handleEdit();
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = `ai-studio-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const resetEditState = () => {
    setOriginalImageFile(null);
    setGeneratedImage(null);
    setPrompt('');
    setError(null);
  };

  const clearMask = () => {
    editorRef.current?.resetMask();
  };

  const promptPlaceholder = mode === AppMode.Edit
    ? "e.g., Change shirt to neon green..."
    : "e.g., A robot holding a red skateboard...";

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text flex flex-col animate-fade-in">
      <Header showBackButton={true} onBack={onExit}/>
      <main className="flex-grow flex flex-col items-center p-4 sm:p-6 lg:p-8 gap-6">
        <ModeToggle mode={mode} setMode={setMode} />
        
        <div className="w-full flex-grow grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel / Controls */}
          <div className="lg:col-span-1 bg-brand-surface/50 p-4 rounded-xl border border-brand-border flex flex-col gap-4 h-full">
            <h3 className="text-xl font-orbitron font-bold text-neon-pink-light">Controls</h3>
            {mode === AppMode.Edit && originalImageFile && (
              <Controls 
                brushSize={brushSize} 
                setBrushSize={setBrushSize} 
                onClearMask={clearMask}
                onNewImage={resetEditState}
              />
            )}
             <form onSubmit={handleSubmit} className="flex-grow flex flex-col gap-4">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={promptPlaceholder}
                  className="w-full flex-grow bg-brand-bg border border-brand-border rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-neon-pink transition-all duration-300 resize-none"
                  rows={4}
                />
                 {error && <p className="text-red-400 text-sm animate-fade-in">{error}</p>}
                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full py-3 px-4 bg-neon-pink text-white font-bold rounded-md hover:bg-neon-pink-light transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-neon-pink/30 hover:scale-105"
                >
                  {isLoading ? 'Processing...' : (mode === AppMode.Edit ? 'Apply Edit' : 'Generate Image')}
                </button>
            </form>
          </div>

          {/* Center Panel / Editor */}
          <div className="lg:col-span-2 w-full h-[60vh] lg:h-auto bg-brand-surface/50 rounded-xl border border-brand-border flex items-center justify-center relative overflow-hidden">
            {isLoading && <LoadingSpinner />}
            {mode === AppMode.Edit ? (
              originalImageFile ? (
                <ImageEditor ref={editorRef} imageFile={originalImageFile} brushSize={brushSize} />
              ) : (
                <ImageUploader onImageUpload={handleImageUpload} />
              )
            ) : (
              !generatedImage && (
                <div className="text-center p-8 animate-fade-in flex flex-col items-center">
                    <img src={LOGO_URL} alt="Logo" className="w-40 h-40 opacity-20 rounded-full"/>
                    <h2 className="text-3xl font-orbitron font-bold text-brand-text mt-4">Generate a New Image</h2>
                    <p className="text-brand-text-secondary mt-2 max-w-md">Use the prompt on the left to describe the image you want to create. Let your imagination run wild!</p>
                </div>
              )
            )}
            {generatedImage && (
                 <div className="w-full h-full p-4 flex flex-col items-center justify-center animate-fade-in">
                    <img src={generatedImage} alt="Generated result" className="max-w-full max-h-[80%] object-contain rounded-lg shadow-2xl shadow-black/50" />
                    <div className="flex gap-4">
                      <button
                          onClick={handleDownload}
                          className="mt-4 py-2 px-6 bg-neon-pink text-white font-bold rounded-md hover:bg-neon-pink-light transition-all duration-300 shadow-lg shadow-neon-pink/30 hover:scale-105"
                      >
                          Download
                      </button>
                      {mode === AppMode.Generate && (
                         <button
                         onClick={() => setGeneratedImage(null)}
                         className="mt-4 py-2 px-6 bg-brand-border text-white font-bold rounded-md hover:bg-gray-600 transition-all duration-300"
                       >
                         Generate Another
                       </button>
                      )}
                    </div>
                 </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};
