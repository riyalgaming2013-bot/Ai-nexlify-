import React, { useState, useEffect } from 'react';
import { AppMode, ViewMode } from './types';
import { LandingPage } from './components/LandingPage';
import { Studio } from './components/Studio';

const App: React.FC = () => {
  const [view, setView] = useState<ViewMode>(ViewMode.Landing);
  const [initialMode, setInitialMode] = useState<AppMode>(AppMode.Edit);

  useEffect(() => {
    // This effect ensures the body background color matches the current view
    if (view === ViewMode.Studio) {
      document.body.classList.add('studio-bg');
    } else {
      document.body.classList.remove('studio-bg');
    }
  }, [view]);


  const handleLaunchStudio = (mode: AppMode) => {
    setInitialMode(mode);
    setView(ViewMode.Studio);
  };

  const handleGoHome = () => {
    setView(ViewMode.Landing);
  };

  return (
    <>
      {view === ViewMode.Landing && <LandingPage onSelectMode={handleLaunchStudio} />}
      {view === ViewMode.Studio && <Studio initialMode={initialMode} onExit={handleGoHome} />}
    </>
  );
};

export default App;