export enum AppMode {
  Edit = 'EDIT',
  Generate = 'GENERATE',
}

export enum ViewMode {
  Landing = 'LANDING',
  Studio = 'STUDIO',
}
