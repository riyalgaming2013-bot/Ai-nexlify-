
import { GoogleGenAI, Modality, Part } from "@google/genai";
import { fileToBase64 } from '../utils/imageUtils';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getBase64FromResponse = (response: any): string => {
    const parts: Part[] | undefined = response?.candidates?.[0]?.content?.parts;
    
    if (parts) {
        for (const part of parts) {
            if (part.inlineData?.data) {
                return part.inlineData.data;
            }
        }
    }
    
    console.error("Failed to find image data in API response", response);
    throw new Error("Could not find image data in API response.");
};

export const generateImageFromPrompt = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        return getBase64FromResponse(response);
    } catch (error) {
        console.error("Error generating image:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate image. API Error: ${error.message}`);
        }
        throw new Error("Failed to generate image. An unknown error occurred.");
    }
};

export const editImageWithMask = async (
    prompt: string,
    imageFile: File,
    maskBase64: string
): Promise<string> => {
    try {
        const imageBase64 = await fileToBase64(imageFile);
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [
                    { text: prompt },
                    { inlineData: { mimeType: imageFile.type, data: imageBase64 } },
                    { inlineData: { mimeType: 'image/png', data: maskBase64 } },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        return getBase64FromResponse(response);
    } catch (error) {
        console.error("Error editing image:", error);
         if (error instanceof Error) {
            throw new Error(`Failed to edit image. API Error: ${error.message}`);
        }
        throw new Error("Failed to edit image. An unknown error occurred.");
    }
};
